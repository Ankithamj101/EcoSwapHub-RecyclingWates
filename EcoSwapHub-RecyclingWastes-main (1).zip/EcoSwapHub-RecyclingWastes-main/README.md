An online interface regarding trading of solid wastes between the customers and the recycling units, 
of the respective solid wastes, which can be used for recycling or creating the energy from waste .

Languages used: HTML,CSS, JavaScript,PHP,Bootstrap,CNN(for Image Classifier).

India generates over 62 million tons (MT) of waste in a year, a large portion of solid waste is being 
dumped in outskirts and rural areas every minute. These wastes are neither being treated nor disposed 
of scientifically. Thus solid waste management is thus a critical issue in India nowadays.
                                                                        
In the past few years a lot of awareness has been created regarding this issue and environment 
enthusiasts have come forward setting up many recycling units for the proper treatment of these wastes ,
but the problem is the waste generated is not isn't reaching these units. 
So even though efforts are made there is no proper connection between the producers and consumers.

Hence our website would be acting as a connection between both the parties to develop the circular 
economy and find a solution to ensure production models are in a closed loop  rather than their disposal.

